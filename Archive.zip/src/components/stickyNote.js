import { useState, useEffect } from "react";
import {Link} from "react-router-dom";
import Paper from '@mui/material/Paper';
import ButtonAppBar from "./header";

function StickyApp(){

    const [stickyNote,setStickyNote] = useState([]);
    const [search,setSearch] = useState("*");

    const displayStickyNote = (searchResult = '*') => {
        console.log(searchResult)
        const parseItem = JSON.parse(localStorage.getItem("stickyNote")) ?? [];
        let stickyNote = [];
        if(parseItem.length>0){
            stickyNote = parseItem.map((item,index)=>{
                if(searchResult!==null || searchResult!==undefined || searchResult.trim()==='' || searchResult==='*'){
                    console.log(searchResult+"+1")

                    if(item.title.toLowerCase().includes(searchResult.toLowerCase()) || item.note.toLowerCase().includes(searchResult.toLowerCase()) || searchResult==='*'){
                        return (
                            <Link   to={`/view/${item.id}`} state={{id:item.id,note:item.note,title:item.title, date:item.date, modified:item?.modified}} >
                            <Paper variant="elevation" elevation={3} style={{position:'relative',height:"100px",width:"100px",display:'inline-table',marginLeft:'50px', marginBottom:'50px', textAlign:'center',padding:'20px'}}>
                            <div key={index} >
                                    <div>
                                       <b> {item.title.substring(0,10)} </b>
                                        <div style={{fontSize:'12px'}}>
                                            {item.title.length>10 && "..."}
                                            {item.note.substring(0,50)}
                                            {item.note.length>50 && "..."}
                                        </div>
                                    </div>
                            </div>
                            </Paper>
                            </Link>
                        )
                    }
                }
            })
        }
        setStickyNote(stickyNote);
    }
    useEffect(()=>{
       displayStickyNote();
    },[])
    return (
        <div>
            <ButtonAppBar searchDisplay={displayStickyNote}/>
     
            <br/> <br/>
            {stickyNote}
            
        </div>
    );
}

export default StickyApp;