import StickyApp from "./components/stickyNote";
import AddNotes from "./components/addNotes";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ViewNotes from "./components/viewNotes";

function App(props) {
  return (
    <div className="App" style={{maxWidth:'99%',margin:'0 auto'}}>
       <BrowserRouter>
        <Routes>
            <Route index element={<StickyApp/>} />
            <Route exact path="/add" element={<AddNotes/>} />
            <Route exact path="/view/:id" element={<ViewNotes/>} />
            <Route path="*" element={<div>* path</div>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;